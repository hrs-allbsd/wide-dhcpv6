# Copyright 2011 The Kyua Authors.
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are
# met:
#
# * Redistributions of source code must retain the above copyright
#   notice, this list of conditions and the following disclaimer.
# * Redistributions in binary form must reproduce the above copyright
#   notice, this list of conditions and the following disclaimer in the
#   documentation and/or other materials provided with the distribution.
# * Neither the name of Google Inc. nor the names of its contributors
#   may be used to endorse or promote products derived from this software
#   without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
# A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
# OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
# SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
# LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
# DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
# THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
# (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

libutils_la_SOURCES += utils/logging/macros.hpp
libutils_la_SOURCES += utils/logging/operations.cpp
libutils_la_SOURCES += utils/logging/operations.hpp
libutils_la_SOURCES += utils/logging/operations_fwd.hpp

if WITH_ATF
tests_utils_loggingdir = $(pkgtestsdir)/utils/logging

tests_utils_logging_DATA = utils/logging/Kyuafile
EXTRA_DIST += $(tests_utils_logging_DATA)

tests_utils_logging_PROGRAMS = utils/logging/macros_test
utils_logging_macros_test_SOURCES = utils/logging/macros_test.cpp
utils_logging_macros_test_CXXFLAGS = $(UTILS_CFLAGS) $(ATF_CXX_CFLAGS)
utils_logging_macros_test_LDADD = $(UTILS_LIBS) $(ATF_CXX_LIBS)

tests_utils_logging_PROGRAMS += utils/logging/operations_test
utils_logging_operations_test_SOURCES = utils/logging/operations_test.cpp
utils_logging_operations_test_CXXFLAGS = $(UTILS_CFLAGS) $(ATF_CXX_CFLAGS)
utils_logging_operations_test_LDADD = $(UTILS_LIBS) $(ATF_CXX_LIBS)
endif
